#ifndef main_h
#define main_h
#include "node.h"
#include "buildTree.h"
#endif